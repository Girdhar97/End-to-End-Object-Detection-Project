# sign language > 2024-06-01 1:48pm
https://universe.roboflow.com/signlang-s4ziq/sign-language-oiulk

Provided by a Roboflow user
License: CC BY 4.0

